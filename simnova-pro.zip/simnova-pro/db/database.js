const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dbDir = __dirname;
fs.mkdirSync(dbDir, { recursive: true });
const db = new Database(path.join(dbDir, 'simnova.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      phone TEXT,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'client' CHECK(role IN ('client','admin')),
      status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','blocked')),
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS plans (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      country TEXT NOT NULL,
      region TEXT,
      data_amount TEXT NOT NULL,
      validity_days INTEGER NOT NULL,
      price REAL NOT NULL,
      old_price REAL,
      network TEXT,
      speed TEXT DEFAULT '4G/5G',
      coverage TEXT,
      description TEXT,
      featured INTEGER NOT NULL DEFAULT 0,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS payment_methods (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      account_title TEXT,
      account_number TEXT,
      instructions TEXT,
      icon TEXT DEFAULT 'bank',
      active INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_no TEXT NOT NULL UNIQUE,
      user_id INTEGER NOT NULL,
      plan_id INTEGER NOT NULL,
      payment_method_id INTEGER,
      amount REAL NOT NULL,
      currency TEXT NOT NULL DEFAULT 'PKR',
      status TEXT NOT NULL DEFAULT 'pending_payment' CHECK(status IN ('pending_payment','payment_submitted','paid','processing','delivered','rejected','cancelled')),
      payment_reference TEXT,
      payment_screenshot TEXT,
      admin_note TEXT,
      esim_qr_text TEXT,
      esim_qr_image TEXT,
      esim_iccid TEXT,
      esim_smdp TEXT,
      esim_activation_code TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE RESTRICT,
      FOREIGN KEY(plan_id) REFERENCES plans(id) ON DELETE RESTRICT,
      FOREIGN KEY(payment_method_id) REFERENCES payment_methods(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);
}

module.exports = { db, initDb };
