require('dotenv').config();
const bcrypt = require('bcryptjs');
const { db, initDb } = require('./database');

initDb();

const adminUsername = process.env.ADMIN_USERNAME || 'admin';
const adminPassword = process.env.ADMIN_PASSWORD || 'ChangeMe123!';
const adminEmail = `${adminUsername.replace(/[^a-z0-9]/gi,'').toLowerCase() || 'admin'}@simnova.local`;

const existingAdmin = db.prepare("SELECT id FROM users WHERE role='admin' LIMIT 1").get();
if (!existingAdmin) {
  const hash = bcrypt.hashSync(adminPassword, 12);
  db.prepare(`INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'admin')`)
    .run(adminUsername, adminEmail, hash);
  console.log(`Created admin user: ${adminEmail}`);
  console.log(`Admin password: value from ADMIN_PASSWORD in .env`);
} else {
  console.log('Admin already exists — skipped.');
}

const planCount = db.prepare('SELECT COUNT(*) c FROM plans').get().c;
if (!planCount) {
  const insert = db.prepare(`INSERT INTO plans
    (title,country,region,data_amount,validity_days,price,old_price,network,speed,coverage,description,featured)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`);
  const plans = [
    ['Saudi Arabia 10GB','Saudi Arabia','Middle East','10 GB',30,5499,6499,'STC / Mobily / Zain','4G/5G','Saudi Arabia','Great for Umrah, business trips and everyday travel.',1],
    ['United Kingdom 20GB','United Kingdom','Europe','20 GB',30,6999,7999,'EE / O2 / Vodafone','4G/5G','United Kingdom','Fast data for UK visitors with broad network coverage.',1],
    ['Europe 30GB','Europe Multi-Country','Europe','30 GB',30,10999,12999,'Multiple Networks','4G/5G','30+ European countries','One eSIM for a multi-country Europe trip.',1],
    ['UAE 5GB','United Arab Emirates','Middle East','5 GB',15,3499,null,'Etisalat / du','4G/5G','UAE','Perfect for short Dubai and UAE trips.',0],
    ['USA 20GB','United States','North America','20 GB',30,7999,8999,'T-Mobile / AT&T','4G/5G','United States','Reliable travel data for the United States.',0],
    ['Global 10GB','Global','Worldwide','10 GB',30,13999,15999,'Multiple Networks','4G/5G','80+ countries','Flexible coverage for frequent international travel.',0]
  ];
  const trx = db.transaction(rows => rows.forEach(r => insert.run(...r)));
  trx(plans);
  console.log(`Seeded ${plans.length} plans.`);
}

const pmCount = db.prepare('SELECT COUNT(*) c FROM payment_methods').get().c;
if (!pmCount) {
  const insert = db.prepare(`INSERT INTO payment_methods (name,account_title,account_number,instructions,icon,sort_order) VALUES (?,?,?,?,?,?)`);
  insert.run('Bank Transfer','SimNova','0000-0000-0000','Transfer the exact order amount, then upload your payment screenshot.','bank',1);
  insert.run('EasyPaisa','SimNova','03XX-XXXXXXX','Send payment and enter the transaction/reference number.','wallet',2);
  console.log('Seeded payment methods.');
}

const settings = {
  store_name: process.env.STORE_NAME || 'SimNova',
  currency: process.env.STORE_CURRENCY || 'PKR',
  hero_title: 'Travel connected. Instantly.',
  hero_subtitle: 'Affordable eSIM plans for your next trip — buy online, submit payment, and receive your activation QR in your account.',
  support_whatsapp: '',
  support_email: 'support@simnova.example'
};
for (const [key,value] of Object.entries(settings)) {
  db.prepare('INSERT OR IGNORE INTO settings (key,value) VALUES (?,?)').run(key,value);
}
console.log('Seeding complete.');
