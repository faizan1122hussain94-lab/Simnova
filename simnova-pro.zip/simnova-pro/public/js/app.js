document.addEventListener('DOMContentLoaded',()=>{
  const btn=document.querySelector('[data-menu]');
  if(btn) btn.addEventListener('click',()=>document.querySelector('.links')?.classList.toggle('open'));
  const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')}),{threshold:.12});
  document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
});
